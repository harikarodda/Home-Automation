<html>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=ISO-8859-1" />
<style type="text/css">
h1 {color:brown}
body { background: url(https://cdn.decoist.com/wp-content/uploads/2014/10/wadia_complete-2.jpg); background-size: 100% 100%; }
</style>
<meta name="description" content="Home Automation usjng IoT" />
<meta name="keywords" content="Raspberry Pi, Motion Sensor, Temperature Sensor, Bread Board" />
<meta name="author" content="Rahul, Harika, Sanjana, Omer" />
<title>Welcome to Home Automation, Anywhere, Anytime</title>
</head>
<body>
<center><h1>Real Time Operating Systems - Final Project</h1></center>
<center><h3>Rahul, Harika, Sanjana, Omer</h3></center>
<<img src="https://www.element14.com/community/dtss-images/uploads/devtool/image/large/Raspberry_Pi_3_Model_B_1GB_RAM.png" alt="Merrill Lynch Ad" align="right" height="380" width="500"/>
<a href="https://diyhacking.com/raspberry-pi-home-automation/" target="_blank"> Read More About Raspberry Pi 3 and Home Automation System</a>

<h3> LIGHT </h3>
<?php
if(isset($_POST['ON3']))
{
exec("sudo python /home/pi/Downloads/led3on.py");
}
if(isset($_POST['OFF3']))
{
exec("sudo python /home/pi/Downloads/led3off.py");
}
?>
<form method="post">
<button name="ON3">ON</button>
<button name="OFF3">OFF</button><br>
</form>

<h3> AC </h3>
<?php
if(isset($_POST['ON2']))
{
exec("sudo python /home/pi/Downloads/led2on.py");
}
if(isset($_POST['OFF2']))
{
exec("sudo python /home/pi/Downloads/led2off.py");
}
?>
<form method="post">
<button name="ON2">ON</button>
<button name="OFF2">OFF</button><br>
</form>

<h3> DISHWASHER </h3>
<?php
if(isset($_POST['ON4']))
{
exec("sudo python /home/pi/Downloads/led4on.py");
}
if(isset($_POST['OFF4']))
{
exec("sudo python /home/pi/Downloads/led4off.py");
}
?>
<form method="post">
<button name="ON4">ON</button>
<button name="OFF4">OFF</button><br>
</form>

<h4>Current Temperature of the room:</h4>
<?php
$temp=fopen("/home/pi/Downloads/temp.txt","r");
echo fgets($temp);
echo "C";
fclose($temp);
?>
<br></br>
<h4>Status of PIR Sensor:</h4>
<?php
$temp1=fopen("/home/pi/Downloads/pir.txt","r");
echo fgets($temp1);
fclose($temp1);
?>


<br></br>
<a href="mailto:omermohammed@my.unt.edu?Subject=Hello%20again">Suggestions?? Please let me know!! Click to email </a>
</body>
</html>