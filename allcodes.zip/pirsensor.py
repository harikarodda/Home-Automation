import time
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)

led1 = 22
led2 = 27
pirpin = 21

GPIO.setup(led1, GPIO.OUT)
GPIO.setup(led2, GPIO.OUT)
GPIO.setup(pirpin, GPIO.IN)

def LIGHTS(pirpin):
	#print("Motion Detected!!")
	print("Lights on")
	f = open("pir.txt","w+")
        f.write("Motion Detected")
        f.close()
	GPIO.output(led1, GPIO.HIGH)
	GPIO.output(led2, GPIO.HIGH)
	time.sleep(3)
	print("Light off")
	f1 = open("pir.txt","w+")
        f1.write("No Motion detected")
        f1.close()
	GPIO.output(led1, GPIO.LOW)
	GPIO.output(led2, GPIO.LOW)

print("Motion Sensor(CTRL+C to exit)")
time.sleep(0.5)
print("Ready")

try:
	GPIO.add_event_detect(pirpin, GPIO.RISING, callback = LIGHTS)
	while(1):
		time.sleep(3)
except KeyboardInterrupt:
	print("Quit")
	GPIO.cleanup()